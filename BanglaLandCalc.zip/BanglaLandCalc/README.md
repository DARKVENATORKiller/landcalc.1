# GJ land (BanglaLandCalc) v2.0

বাংলাদেশের জমি-বিষয়ক অ্যাপ: Kotlin + Jetpack Compose + Room।

## ফিচার
- AI সহকারী: অফলাইন (বিল্ট-ইন প্রশ্নোত্তর ভাণ্ডার) + অনলাইন (Gemini, নিজের ফ্রি API Key)
- গাইড: কেনার কাগজপত্র, নামজারি, খাজনা, খতিয়ান, দলিল-রেজিস্ট্রেশন, ওয়ারিশ, প্রতারণা সতর্কতা
- কেনার চেকলিস্ট (টিক সংরক্ষিত থাকে)
- টুলস: একক রূপান্তর, দৈর্ঘ্য×প্রস্থ, কেনা-বেচা খরচ, খাজনা বকেয়া, সরকারি পোর্টাল লিংক
- জমির রেকর্ড সংরক্ষণ (Room)
- লোগো: res/drawable/ic_fg.xml (adaptive icon)

## ফাইল ম্যাপ
- ai/KnowledgeBase.kt — অফলাইন তথ্য (এখানে নতুন প্রশ্নোত্তর যোগ করুন)
- ai/OfflineEngine.kt — অফলাইন খোঁজ
- ai/OnlineAi.kt — Gemini API
- ai/ChatViewModel.kt — অনলাইন/অফলাইন সিদ্ধান্ত
- app/gj-debug.keystore — স্থির debug কী (আপডেট ইনস্টলের জন্য; Play Store-এর জন্য নয়)

## বিল্ড
Android Studio: Build > Build APK(s)। অথবা GitHub Actions workflow (`gradle assembleDebug`)।
