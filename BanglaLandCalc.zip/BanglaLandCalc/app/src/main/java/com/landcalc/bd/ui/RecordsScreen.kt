package com.landcalc.bd.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.landcalc.bd.*
import com.landcalc.bd.data.*

@Composable
fun RecordsScreen(modifier: Modifier = Modifier, vm: RecordsViewModel = viewModel()) {
    val list by vm.records.collectAsStateWithLifecycle()
    var show by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    Box(modifier.fillMaxSize()) {
        if (list.isEmpty()) {
            Text("কোনো রেকর্ড নেই। + চাপ দিয়ে জমির তথ্য সংরক্ষণ করুন।",
                modifier = Modifier.align(Alignment.Center).padding(24.dp))
        }
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(list, key = { it.id }) { r ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(r.title, style = MaterialTheme.typography.titleMedium)
                        Text("মালিক: ${r.ownerName}")
                        Text("মৌজা: ${r.mouja} | খতিয়ান: ${r.khatianNo} | দাগ: ${r.dagNo}")
                        Text("পরিমাণ: ${fmt(r.areaShotok)} শতক (${fmt(r.areaShotok * LandUnit.SHOTOK.sqft)} বর্গফুট)")
                        if (r.notes.isNotBlank()) Text("নোট: ${r.notes}")
                        Row {
                            TextButton(onClick = {
                                shareText(ctx, "${r.title}\nমালিক: ${r.ownerName}\nমৌজা: ${r.mouja}, খতিয়ান: ${r.khatianNo}, দাগ: ${r.dagNo}\nপরিমাণ: ${fmt(r.areaShotok)} শতক")
                            }) { Text("শেয়ার") }
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { vm.delete(r) }) {
                                Icon(Icons.Default.Delete, contentDescription = "মুছুন")
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(72.dp)) }
        }
        FloatingActionButton(
            onClick = { show = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = "নতুন রেকর্ড") }
    }

    if (show) AddRecordDialog(onDismiss = { show = false }) { vm.add(it); show = false }
}

@Composable
private fun AddRecordDialog(onDismiss: () -> Unit, onSave: (LandRecord) -> Unit) {
    var title by remember { mutableStateOf("") }
    var owner by remember { mutableStateOf("") }
    var mouja by remember { mutableStateOf("") }
    var khatian by remember { mutableStateOf("") }
    var dag by remember { mutableStateOf("") }
    var area by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন জমির রেকর্ড") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("শিরোনাম *") }, singleLine = true)
                OutlinedTextField(owner, { owner = it }, label = { Text("মালিকের নাম") }, singleLine = true)
                OutlinedTextField(mouja, { mouja = it }, label = { Text("মৌজা") }, singleLine = true)
                OutlinedTextField(khatian, { khatian = it }, label = { Text("খতিয়ান নং") }, singleLine = true)
                OutlinedTextField(dag, { dag = it }, label = { Text("দাগ নং") }, singleLine = true)
                OutlinedTextField(area, { area = it }, label = { Text("পরিমাণ (শতক) *") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(notes, { notes = it }, label = { Text("নোট") })
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = parseNum(area)
                if (title.isBlank() || a == null) {
                    error = "শিরোনাম ও সঠিক পরিমাণ দিন"
                } else {
                    onSave(LandRecord(title = title.trim(), ownerName = owner, mouja = mouja,
                        khatianNo = khatian, dagNo = dag, areaShotok = a, notes = notes))
                }
            }) { Text("সংরক্ষণ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}
