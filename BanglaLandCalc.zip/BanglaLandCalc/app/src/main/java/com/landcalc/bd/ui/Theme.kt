package com.landcalc.bd.ui

import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

val GjGreen = Color(0xFF1B6B3A)

val GjColors = lightColorScheme(
    primary = GjGreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDEBD3),
    onPrimaryContainer = Color(0xFF002111),
    secondary = Color(0xFF4F6354),
    secondaryContainer = Color(0xFFE2F0E4),
    tertiary = Color(0xFFB57F00),
    surfaceVariant = Color(0xFFEFF3EE)
)
