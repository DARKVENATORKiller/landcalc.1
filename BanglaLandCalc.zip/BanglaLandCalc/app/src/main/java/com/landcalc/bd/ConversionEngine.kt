package com.landcalc.bd

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/** সব একক বর্গফুটে রূপান্তরিত হয়। বিঘা = ২০ কাঠা (ঢাকা মান); অঞ্চলভেদে ভিন্ন হতে পারে। */
enum class LandUnit(val bn: String, val sqft: Double) {
    SQFT("বর্গফুট", 1.0),
    SQM("বর্গমিটার", 10.763910417),
    CHHATAK("ছটাক", 45.0),
    KATHA("কাঠা", 720.0),
    SHOTOK("শতক", 435.6),
    BIGHA("বিঘা", 14400.0),
    ACRE("একর", 43560.0),
    HECTARE("হেক্টর", 107639.104)
}

object ConversionEngine {
    fun convert(value: Double, from: LandUnit, to: LandUnit): Double =
        value * from.sqft / to.sqft

    fun convertAll(value: Double, from: LandUnit): List<Pair<LandUnit, Double>> =
        LandUnit.values().map { it to convert(value, from, it) }

    /** ফুটে দৈর্ঘ্য × প্রস্থ = বর্গফুট; মিটার হলে বর্গমিটার থেকে বর্গফুট */
    fun areaSqft(length: Double, width: Double, meters: Boolean): Double {
        val a = length * width
        return if (meters) a * LandUnit.SQM.sqft else a
    }
}

fun parseNum(s: String): Double? {
    val sb = StringBuilder()
    for (c in s) {
        when {
            c in '০'..'৯' -> sb.append('0' + (c - '০'))
            c in '0'..'9' || c == '.' -> sb.append(c)
        }
    }
    return sb.toString().toDoubleOrNull()
}

fun toBnDigits(s: String): String =
    s.map { if (it in '0'..'9') '০' + (it - '0') else it }.joinToString("")

fun fmt(d: Double): String =
    toBnDigits(DecimalFormat("#,##0.####", DecimalFormatSymbols(Locale.US)).format(d))

fun fmtTaka(d: Double): String =
    "৳ " + toBnDigits(DecimalFormat("#,##0.##", DecimalFormatSymbols(Locale.US)).format(d))
