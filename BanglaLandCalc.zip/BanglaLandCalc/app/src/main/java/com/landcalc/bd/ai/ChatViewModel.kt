package com.landcalc.bd.ai

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.landcalc.bd.data.Prefs
import kotlinx.coroutines.launch

data class ChatMsg(
    val fromUser: Boolean,
    val text: String,
    val source: String = "",
    val related: List<String> = emptyList()
)

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    val messages = mutableStateListOf<ChatMsg>()
    var busy by mutableStateOf(false)
        private set

    private fun isOnline(): Boolean {
        val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun send(question: String) {
        val q = question.trim()
        if (q.isEmpty() || busy) return
        val history = messages.takeLast(6).map { it.fromUser to it.text }
        messages.add(ChatMsg(true, q))
        busy = true

        viewModelScope.launch {
            val prefs = Prefs(getApplication<Application>())
            val hits = OfflineEngine.search(q, 3)
            var note = ""
            var onlineText: String? = null

            if (prefs.mode == 0 && prefs.apiKey.isNotBlank()) {
                if (isOnline()) {
                    val ctx = hits.filter { it.score >= OfflineEngine.CONFIDENT * 0.6 }
                        .joinToString("\n\n") { "【${it.kb.title}】\n${it.kb.answer}" }
                    val r = OnlineAi.ask(prefs.apiKey, prefs.model, history, q, ctx)
                    onlineText = r.getOrNull()
                    if (onlineText == null) note = r.exceptionOrNull()?.message ?: "অনলাইন AI উত্তর দেয়নি"
                } else {
                    note = "ইন্টারনেট নেই"
                }
            }

            val reply = if (onlineText != null) {
                ChatMsg(
                    false,
                    OnlineAi.cleanMarkdown(onlineText) + "\n\n" + KnowledgeBase.DISCLAIMER,
                    "অনলাইন AI",
                    hits.take(2).map { it.kb.title }
                )
            } else {
                offlineReply(hits, note, prefs.apiKey.isBlank() && prefs.mode == 0)
            }
            messages.add(reply)
            busy = false
        }
    }

    private fun offlineReply(hits: List<OfflineEngine.Hit>, note: String, noKey: Boolean): ChatMsg {
        val prefix = if (note.isNotBlank()) "(অনলাইন AI পাওয়া যায়নি: $note — অফলাইন উত্তর দেখাচ্ছি)\n\n" else ""
        val best = hits.firstOrNull()
        return if (best != null && best.score >= OfflineEngine.CONFIDENT) {
            ChatMsg(
                false,
                prefix + best.kb.title + "\n\n" + best.kb.answer + "\n\n" + KnowledgeBase.DISCLAIMER,
                "অফলাইন",
                hits.drop(1).filter { it.score >= OfflineEngine.CONFIDENT * 0.5 }.map { it.kb.title }
            )
        } else {
            val tip = if (noKey) "\n\nআরও উত্তর পেতে সেটিংসে Gemini API Key বসান (ফ্রি) — তখন ইন্টারনেট থাকলে যেকোনো জমি-প্রশ্নের উত্তর পাবেন।" else ""
            ChatMsg(
                false,
                prefix + "এই প্রশ্নের নির্দিষ্ট উত্তর অফলাইন তথ্যভাণ্ডারে পাইনি। নিচের কাছাকাছি বিষয়গুলো দেখতে পারেন বা প্রশ্নটি অন্যভাবে লিখুন।$tip",
                "অফলাইন",
                if (hits.isNotEmpty()) hits.map { it.kb.title }
                else KnowledgeBase.quickQuestions.take(3)
            )
        }
    }
}
