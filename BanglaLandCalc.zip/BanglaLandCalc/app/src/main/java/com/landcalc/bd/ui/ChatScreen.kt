package com.landcalc.bd.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.landcalc.bd.ai.ChatMsg
import com.landcalc.bd.ai.ChatViewModel
import com.landcalc.bd.ai.KnowledgeBase

@Composable
fun ChatScreen(modifier: Modifier = Modifier, vm: ChatViewModel = viewModel()) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val msgs = vm.messages

    LaunchedEffect(msgs.size, vm.busy) {
        val last = msgs.size - 1 + (if (vm.busy) 1 else 0)
        if (msgs.isNotEmpty() && last >= 0) listState.animateScrollToItem(last)
    }

    Column(modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (msgs.isEmpty()) {
                item { Welcome { vm.send(it) } }
            }
            items(msgs) { m -> Bubble(m) { vm.send(it) } }
            if (vm.busy) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Text("উত্তর খুঁজছি...")
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("জমির প্রশ্ন লিখুন...") },
                maxLines = 4
            )
            Button(
                onClick = { vm.send(input); input = "" },
                enabled = !vm.busy && input.isNotBlank()
            ) { Text("পাঠান") }
        }
    }
}

@Composable
private fun Welcome(onPick: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("আসসালামু আলাইকুম! 👋", style = MaterialTheme.typography.titleLarge)
        Text(
            "আমি GJ land সহকারী। জমি কেনাবেচার কাগজপত্র, নামজারি, খাজনা, দলিল, ওয়ারিশ, মালিকানা যাচাই—বাংলাদেশের জমি নিয়ে যেকোনো প্রশ্ন করুন। ইন্টারনেট ছাড়াও (অফলাইন) অনেক উত্তর দিতে পারি।",
            style = MaterialTheme.typography.bodyMedium
        )
        Text("কিছু প্রশ্ন:", style = MaterialTheme.typography.labelLarge)
        KnowledgeBase.quickQuestions.forEach { q ->
            OutlinedButton(onClick = { onPick(q) }, modifier = Modifier.fillMaxWidth()) { Text(q) }
        }
    }
}

@Composable
private fun Bubble(m: ChatMsg, onAsk: (String) -> Unit) {
    val align = if (m.fromUser) Alignment.End else Alignment.Start
    Column(Modifier.fillMaxWidth(), horizontalAlignment = align) {
        Card(
            modifier = Modifier.widthIn(max = 330.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (!m.fromUser && m.source.isNotBlank()) {
                    Text(
                        "● ${m.source}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                SelectionContainer { Text(m.text, style = MaterialTheme.typography.bodyMedium) }
                if (m.related.isNotEmpty()) {
                    Text("আরও দেখুন:", style = MaterialTheme.typography.labelMedium)
                    m.related.forEach { t ->
                        TextButton(onClick = { onAsk(t) }, contentPadding = PaddingValues(horizontal = 4.dp)) {
                            Text("➜ $t")
                        }
                    }
                }
            }
        }
    }
}
