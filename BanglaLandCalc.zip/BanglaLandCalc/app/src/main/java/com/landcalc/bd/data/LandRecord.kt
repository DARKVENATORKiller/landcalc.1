package com.landcalc.bd.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "land_records")
data class LandRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val ownerName: String,
    val mouja: String,
    val khatianNo: String,
    val dagNo: String,
    val areaShotok: Double,
    val notes: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface LandDao {
    @Query("SELECT * FROM land_records ORDER BY createdAt DESC")
    fun all(): Flow<List<LandRecord>>

    @Insert
    suspend fun insert(r: LandRecord)

    @Delete
    suspend fun delete(r: LandRecord)
}

@Database(entities = [LandRecord::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): LandDao

    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: android.content.Context): AppDatabase =
            inst ?: synchronized(this) {
                inst ?: Room.databaseBuilder(
                    ctx.applicationContext, AppDatabase::class.java, "land.db"
                ).build().also { inst = it }
            }
    }
}
