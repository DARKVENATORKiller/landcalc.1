package com.landcalc.bd.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.landcalc.bd.ai.Kb
import com.landcalc.bd.ai.KnowledgeBase
import com.landcalc.bd.ai.OfflineEngine
import com.landcalc.bd.data.Prefs

@Composable
fun GuideScreen(modifier: Modifier = Modifier) {
    var tab by remember { mutableIntStateOf(0) }
    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("বিষয়ভিত্তিক গাইড") })
            FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("কেনার চেকলিস্ট") })
        }
        if (tab == 0) TopicList() else ChecklistView()
    }
}

@Composable
private fun TopicList() {
    var query by remember { mutableStateOf("") }
    var open by remember { mutableStateOf<String?>(null) }
    val searching = query.isNotBlank()
    val entries: List<Kb> =
        if (searching) OfflineEngine.search(query, 10).map { it.kb } else KnowledgeBase.entries
    val grouped = entries.groupBy { it.cat }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            placeholder = { Text("খুঁজুন: নামজারি, খাজনা, দলিল...") },
            singleLine = true
        )
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (searching && entries.isEmpty()) {
                item { Text("কিছু পাওয়া যায়নি। অন্য শব্দ দিয়ে চেষ্টা করুন বা 'সহকারী' ট্যাবে প্রশ্ন করুন।") }
            }
            grouped.forEach { (cat, list) ->
                item(key = "h_$cat") {
                    Text(
                        cat,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                items(list, key = { it.id }) { kb ->
                    KbCard(kb, open == kb.id) { open = if (open == kb.id) null else kb.id }
                }
            }
        }
    }
}

@Composable
private fun KbCard(kb: Kb, expanded: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(kb.title, style = MaterialTheme.typography.titleSmall)
            if (expanded) {
                SelectionContainer { Text(kb.answer, style = MaterialTheme.typography.bodyMedium) }
                Text(KnowledgeBase.DISCLAIMER, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ChecklistView() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var checked by remember { mutableStateOf(prefs.checked) }
    val total = KnowledgeBase.checklist.sumOf { it.second.size }
    val done = checked.size.coerceAtMost(total)

    fun toggle(id: String) {
        val n = if (id in checked) checked - id else checked + id
        checked = n
        prefs.checked = n
    }

    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("জমি কেনার আগে যাচাই ($done/$total)", style = MaterialTheme.typography.titleMedium)
                LinearProgressIndicator(
                    progress = { if (total == 0) 0f else done.toFloat() / total },
                    modifier = Modifier.fillMaxWidth()
                )
                TextButton(onClick = { checked = emptySet(); prefs.checked = emptySet() }) { Text("সব মুছুন") }
            }
        }
        KnowledgeBase.checklist.forEach { (section, list) ->
            item(key = "s_$section") {
                Text(
                    section,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            list.forEachIndexed { i, text ->
                val id = "$section|$i"
                item(key = id) {
                    Row(
                        Modifier.fillMaxWidth().clickable { toggle(id) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = id in checked, onCheckedChange = { toggle(id) })
                        Text(text, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        item { Text(KnowledgeBase.DISCLAIMER, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 12.dp)) }
    }
}
