package com.landcalc.bd.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.landcalc.bd.*

@Composable
fun ConverterScreen(modifier: Modifier = Modifier) {
    var input by remember { mutableStateOf("") }
    var from by remember { mutableStateOf(LandUnit.SHOTOK) }
    val ctx = LocalContext.current
    val v = parseNum(input)

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = input, onValueChange = { input = it },
            label = { Text("জমির পরিমাণ") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
        Text("কোন এককে দিচ্ছেন?", style = MaterialTheme.typography.labelLarge)
        UnitChips(from) { from = it }

        if (v != null) {
            val rows = ConversionEngine.convertAll(v, from)
            val lines = rows.map { (u, r) -> "${u.bn}: ${fmt(r)}" }
            ResultCard("${fmt(v)} ${from.bn} =", lines) {
                shareText(ctx, "${fmt(v)} ${from.bn}\n" + lines.joinToString("\n"))
            }
        } else {
            Text("সংখ্যা লিখলে সব এককে ফলাফল দেখাবে (বাংলা বা ইংরেজি অঙ্ক)।")
        }
        Text(UNIT_NOTE, style = MaterialTheme.typography.bodySmall)
    }
}
