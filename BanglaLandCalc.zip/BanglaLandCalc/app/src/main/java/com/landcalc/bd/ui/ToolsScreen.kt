package com.landcalc.bd.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp

@Composable
fun ToolsScreen(modifier: Modifier = Modifier) {
    var tool by remember { mutableIntStateOf(-1) }
    BackHandler(enabled = tool >= 0) { tool = -1 }

    if (tool < 0) {
        ToolList(modifier) { tool = it }
    } else {
        Column(modifier.fillMaxSize()) {
            TextButton(onClick = { tool = -1 }) { Text("← সব টুল") }
            Box(Modifier.weight(1f)) {
                when (tool) {
                    0 -> ConverterScreen()
                    1 -> DimensionScreen()
                    2 -> CostScreen()
                    else -> KhajnaScreen()
                }
            }
        }
    }
}

@Composable
private fun ToolList(modifier: Modifier, onOpen: (Int) -> Unit) {
    val uri = LocalUriHandler.current
    val ctx = LocalContext.current
    val tools = listOf(
        Triple("📐 জমির একক রূপান্তর", "শতক, কাঠা, ছটাক, বিঘা, একর, বর্গফুট, বর্গমিটার", 0),
        Triple("📏 দৈর্ঘ্য × প্রস্থ", "মাপ দিলে মোট বর্গফুট, শতক, কাঠা", 1),
        Triple("🏷️ কেনা-বেচা খরচ", "জমির দাম + স্ট্যাম্প, রেজিস্ট্রেশন ও কর", 2),
        Triple("💰 খাজনা বকেয়া হিসাব", "দাখিলার অঙ্ক ও বছর দিয়ে মোট বকেয়া", 3)
    )
    val links = listOf(
        "ভূমি মন্ত্রণালয় (land.gov.bd)" to "https://land.gov.bd",
        "খাজনা পরিশোধ (ldtax.gov.bd)" to "https://ldtax.gov.bd",
        "ই-নামজারি (mutation.land.gov.bd)" to "https://mutation.land.gov.bd",
        "ই-পর্চা / অনলাইন খতিয়ান (eporcha.gov.bd)" to "https://eporcha.gov.bd"
    )

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        tools.forEach { (title, sub, id) ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onOpen(id) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    Text(sub, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Text("সরকারি সেবা (ইন্টারনেট লাগবে)", style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp))
        links.forEach { (label, url) ->
            OutlinedButton(onClick = { uri.openUri(url) }, modifier = Modifier.fillMaxWidth()) { Text(label) }
        }
        OutlinedButton(
            onClick = { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:16122"))) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("📞 ভূমি হটলাইন ১৬১২২ (কল)") }
        Text("শুধু .gov.bd ঠিকানা ব্যবহার করুন; দালাল বা ভুয়া সাইট থেকে সাবধান।", style = MaterialTheme.typography.bodySmall)
    }
}
