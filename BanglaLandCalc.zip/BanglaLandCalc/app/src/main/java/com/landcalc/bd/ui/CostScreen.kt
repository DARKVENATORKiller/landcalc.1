package com.landcalc.bd.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.landcalc.bd.*

@Composable
fun CostScreen(modifier: Modifier = Modifier) {
    var area by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf(LandUnit.SHOTOK) }
    var stamp by remember { mutableStateOf("1.5") }
    var regFee by remember { mutableStateOf("1") }
    var localTax by remember { mutableStateOf("2") }
    var srcTax by remember { mutableStateOf("0") }
    var other by remember { mutableStateOf("0") }
    val ctx = LocalContext.current
    val kb = KeyboardOptions(keyboardType = KeyboardType.Decimal)

    val a = parseNum(area)
    val p = parseNum(price)

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("এই একক ধরে পরিমাণ ও দাম দিন:", style = MaterialTheme.typography.labelLarge)
        UnitChips(unit) { unit = it }
        OutlinedTextField(area, { area = it }, label = { Text("জমির পরিমাণ (${unit.bn})") },
            singleLine = true, keyboardOptions = kb, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(price, { price = it }, label = { Text("প্রতি ${unit.bn} দাম (টাকা)") },
            singleLine = true, keyboardOptions = kb, modifier = Modifier.fillMaxWidth())

        Text("খরচের হার (%) — নিজে যাচাই করে পরিবর্তন করুন", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(stamp, { stamp = it }, label = { Text("স্ট্যাম্প") }, singleLine = true,
                keyboardOptions = kb, modifier = Modifier.weight(1f))
            OutlinedTextField(regFee, { regFee = it }, label = { Text("রেজি. ফি") }, singleLine = true,
                keyboardOptions = kb, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(localTax, { localTax = it }, label = { Text("স্থানীয় কর") }, singleLine = true,
                keyboardOptions = kb, modifier = Modifier.weight(1f))
            OutlinedTextField(srcTax, { srcTax = it }, label = { Text("উৎসে কর") }, singleLine = true,
                keyboardOptions = kb, modifier = Modifier.weight(1f))
        }
        OutlinedTextField(other, { other = it }, label = { Text("অন্যান্য খরচ (টাকা)") }, singleLine = true,
            keyboardOptions = kb, modifier = Modifier.fillMaxWidth())

        if (a != null && p != null) {
            val land = a * p
            fun pct(s: String) = land * (parseNum(s) ?: 0.0) / 100.0
            val s1 = pct(stamp); val s2 = pct(regFee); val s3 = pct(localTax); val s4 = pct(srcTax)
            val o = parseNum(other) ?: 0.0
            val total = land + s1 + s2 + s3 + s4 + o
            val sqft = ConversionEngine.convert(a, unit, LandUnit.SQFT)
            val lines = listOf(
                "জমির মূল্য: ${fmtTaka(land)}",
                "স্ট্যাম্প: ${fmtTaka(s1)}",
                "রেজিস্ট্রেশন ফি: ${fmtTaka(s2)}",
                "স্থানীয় কর: ${fmtTaka(s3)}",
                "উৎস কর: ${fmtTaka(s4)}",
                "অন্যান্য: ${fmtTaka(o)}",
                "মোট ব্যয়: ${fmtTaka(total)}",
                "প্রতি বর্গফুট (মোট ব্যয়): ${fmtTaka(total / sqft)}"
            )
            ResultCard("কেনার মোট হিসাব", lines) { shareText(ctx, lines.joinToString("\n")) }
        }
        Text("সতর্কতা: সাধারণ বিক্রয় দলিলে রেজিস্ট্রেশন ফি ১% ও স্ট্যাম্প শুল্ক ১.৫% ধরা হয়েছে। স্থানীয় সরকার কর ও উৎসে কর (গেইন ট্যাক্স) এলাকা ও জমির ধরনভেদে ভিন্ন এবং বাজেটে বদলায়, তাই এ দুটো সাব-রেজিস্ট্রি অফিস বা দলিল লেখক থেকে জেনে বসান।",
            style = MaterialTheme.typography.bodySmall)
    }
}
