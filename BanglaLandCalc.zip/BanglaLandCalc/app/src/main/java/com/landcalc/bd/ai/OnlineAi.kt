package com.landcalc.bd.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Google Gemini API (ফ্রি টিয়ারে চলে; ব্যবহারকারী নিজের API Key বসান)। */
object OnlineAi {

    val defaultModel = "gemini-3.5-flash-lite"

    private val fallbackModels = listOf("gemini-3.5-flash-lite", "gemini-3.8-flash", "gemini-3.5-flash", "gemini-2.5-flash")

    private const val SYSTEM = """তুমি 'GJ land' অ্যাপের জমি-বিষয়ক তথ্য সহকারী। বাংলাদেশের জমি সংক্রান্ত প্রশ্নের উত্তর সহজ বাংলায় দাও: জমি কেনাবেচার কাগজপত্র, দলিল ও রেজিস্ট্রেশন, নামজারি (মিউটেশন), ভূমি উন্নয়ন কর (খাজনা), খতিয়ান, ওয়ারিশ, মালিকানা যাচাই, প্রতারণা থেকে সতর্কতা।
নিয়ম:
- উত্তর সংক্ষিপ্ত ও ধাপে ধাপে দাও, প্রয়োজনে বুলেট ব্যবহার করো।
- নিচে দেওয়া 'রেফারেন্স তথ্য' থাকলে সেটাকে ভিত্তি ধরো। রেফারেন্সের সাথে তোমার জানা তথ্য না মিললে বা নিশ্চিত না হলে স্পষ্ট বলো যে নিশ্চিত নও।
- ফি, কর ও আইনের ধারা সময়ের সাথে বদলায়; সংখ্যা বললে যাচাই করে নিতে বলো এবং সরকারি উৎস (land.gov.bd, mutation.land.gov.bd, ldtax.gov.bd, ১৬১২২) দেখাও।
- তুমি আইনজীবী নও; বড় সিদ্ধান্তে ভূমি অফিস বা আইনজীবীর পরামর্শ নিতে বলো।
- জমির বাইরের প্রশ্নে বিনয়ের সাথে জানাও যে তুমি জমি-বিষয়ক সহকারী।
- ব্যবহারকারীর NID, ফোন নম্বর বা ব্যক্তিগত তথ্য চেয়ো না।"""

    class AiException(msg: String) : Exception(msg)

    suspend fun ask(
        apiKey: String,
        model: String,
        history: List<Pair<Boolean, String>>,   // (fromUser, text)
        question: String,
        context: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val models = (listOf(model.ifBlank { defaultModel }) + fallbackModels).distinct()
        var lastErr = "অজানা ত্রুটি"
        for (m in models) {
            try {
                return@withContext Result.success(call(apiKey, m, history, question, context))
            } catch (e: AiException) {
                lastErr = e.message ?: lastErr
                if (!(e.message ?: "").startsWith("MODEL:")) {
                    return@withContext Result.failure(e)
                }
            } catch (e: Exception) {
                return@withContext Result.failure(AiException("ইন্টারনেট/সংযোগে সমস্যা: ${e.message}"))
            }
        }
        Result.failure(AiException(lastErr.removePrefix("MODEL:")))
    }

    private fun call(
        key: String, model: String,
        history: List<Pair<Boolean, String>>, question: String, context: String
    ): String {
        val contents = JSONArray()
        for ((fromUser, text) in history) {
            contents.put(
                JSONObject()
                    .put("role", if (fromUser) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val finalQ = if (context.isBlank()) question
        else "রেফারেন্স তথ্য:\n$context\n\nপ্রশ্ন: $question"
        contents.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", finalQ)))
        )

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.3).put("maxOutputTokens", 1500))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 45000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            if (code in 200..299) return parse(text)

            val apiMsg = try {
                JSONObject(text).getJSONObject("error").optString("message", "")
            } catch (e: Exception) { "" }
            when (code) {
                404 -> throw AiException("MODEL:মডেল '$model' পাওয়া যায়নি। সেটিংসে মডেলের নাম বদলে দেখুন।")
                400 -> {
                    if (apiMsg.contains("API key", ignoreCase = true))
                        throw AiException("API Key সঠিক নয়। সেটিংসে আবার বসান।")
                    throw AiException("MODEL:অনুরোধ গ্রহণ হয়নি (400): $apiMsg")
                }
                401, 403 -> throw AiException("API Key কাজ করছে না বা অনুমতি নেই ($code)।")
                429 -> throw AiException("ফ্রি সীমা (রিকোয়েস্ট লিমিট) শেষ। কিছুক্ষণ পরে চেষ্টা করুন।")
                else -> throw AiException("সার্ভার ত্রুটি ($code)। $apiMsg")
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(json: String): String {
        val root = JSONObject(json)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) throw AiException("AI কোনো উত্তর দেয়নি (নিরাপত্তা ফিল্টার হতে পারে)।")
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw AiException("AI-এর উত্তর খালি এসেছে।")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        val out = sb.toString().trim()
        if (out.isEmpty()) throw AiException("AI-এর উত্তর খালি এসেছে।")
        return out
    }

    fun cleanMarkdown(s: String): String =
        s.replace("**", "")
            .replace("`", "")
            .replace(Regex("(?m)^#+\\s*"), "")
            .replace(Regex("(?m)^\\s*[*-]\\s+"), "• ")
}
