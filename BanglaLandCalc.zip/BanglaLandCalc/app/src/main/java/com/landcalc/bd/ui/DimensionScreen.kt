package com.landcalc.bd.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.landcalc.bd.*

@Composable
fun DimensionScreen(modifier: Modifier = Modifier) {
    var l by remember { mutableStateOf("") }
    var w by remember { mutableStateOf("") }
    var meters by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val lv = parseNum(l)
    val wv = parseNum(w)
    val kb = KeyboardOptions(keyboardType = KeyboardType.Decimal)

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !meters, onClick = { meters = false }, label = { Text("ফুট") })
            FilterChip(selected = meters, onClick = { meters = true }, label = { Text("মিটার") })
        }
        OutlinedTextField(l, { l = it }, label = { Text("দৈর্ঘ্য") }, singleLine = true,
            keyboardOptions = kb, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(w, { w = it }, label = { Text("প্রস্থ") }, singleLine = true,
            keyboardOptions = kb, modifier = Modifier.fillMaxWidth())

        if (lv != null && wv != null) {
            val sqft = ConversionEngine.areaSqft(lv, wv, meters)
            val lines = listOf(LandUnit.SQFT, LandUnit.SQM, LandUnit.SHOTOK, LandUnit.KATHA, LandUnit.BIGHA, LandUnit.ACRE)
                .map { "${it.bn}: ${fmt(ConversionEngine.convert(sqft, LandUnit.SQFT, it))}" }
            val unit = if (meters) "মিটার" else "ফুট"
            ResultCard("${fmt(lv)} × ${fmt(wv)} $unit", lines) {
                shareText(ctx, "জমি: ${fmt(lv)} × ${fmt(wv)} $unit\n" + lines.joinToString("\n"))
            }
        }
        Text("সতর্কতা: এটি আয়তক্ষেত্র ধরে হিসাব। অসম আকারের জমির জন্য সার্ভেয়ারের মাপ নিন।",
            style = MaterialTheme.typography.bodySmall)
        Text(UNIT_NOTE, style = MaterialTheme.typography.bodySmall)
    }
}
