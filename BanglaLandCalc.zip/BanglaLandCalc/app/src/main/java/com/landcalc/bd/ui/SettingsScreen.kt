package com.landcalc.bd.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.landcalc.bd.ai.OnlineAi
import com.landcalc.bd.data.Prefs
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val uri = LocalUriHandler.current
    val prefs = remember { Prefs(ctx) }
    var key by remember { mutableStateOf(prefs.apiKey) }
    var model by remember { mutableStateOf(prefs.model) }
    var mode by remember { mutableIntStateOf(prefs.mode) }
    var result by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun save() {
        prefs.apiKey = key
        prefs.model = model
        prefs.mode = mode
    }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("AI সহকারী সেটিংস", style = MaterialTheme.typography.titleMedium)

        Text("মোড", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == 0, onClick = { mode = 0; save() }, label = { Text("অটো (অনলাইন + অফলাইন)") })
            FilterChip(selected = mode == 1, onClick = { mode = 1; save() }, label = { Text("শুধু অফলাইন") })
        }
        Text(
            "অটো: ইন্টারনেট ও API Key থাকলে অনলাইন AI উত্তর দেয়, না থাকলে নিজে থেকেই অফলাইন তথ্যভাণ্ডার থেকে উত্তর দেয়।",
            style = MaterialTheme.typography.bodySmall
        )

        OutlinedTextField(
            value = key, onValueChange = { key = it },
            label = { Text("Gemini API Key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = model, onValueChange = { model = it },
            label = { Text("মডেলের নাম (ফাঁকা রাখলে ডিফল্ট)") },
            placeholder = { Text(OnlineAi.defaultModel) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { save(); result = "সংরক্ষণ হয়েছে ✅" }) { Text("সংরক্ষণ") }
            OutlinedButton(
                enabled = !testing && key.isNotBlank(),
                onClick = {
                    save()
                    testing = true
                    result = "পরীক্ষা চলছে..."
                    scope.launch {
                        val r = OnlineAi.ask(key, model, emptyList(), "এক বাক্যে বলো: নামজারি কী?", "")
                        result = r.fold(
                            { "✅ কাজ করছে:\n" + OnlineAi.cleanMarkdown(it).take(200) },
                            { "❌ " + (it.message ?: "ব্যর্থ") }
                        )
                        testing = false
                    }
                }
            ) { Text("কানেকশন টেস্ট") }
        }
        if (result.isNotBlank()) Text(result, style = MaterialTheme.typography.bodyMedium)

        Text("ফ্রি API Key কীভাবে পাবেন", style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp))
        Text(
            "১) নিচের বাটনে Google AI Studio খুলুন ও Google অ্যাকাউন্টে লগইন করুন\n২) 'Create API key' চাপুন\n৩) কী কপি করে এখানে বসিয়ে সংরক্ষণ করুন, তারপর 'কানেকশন টেস্ট' চাপুন\nফ্রি টিয়ারে দৈনিক ও মিনিটভিত্তিক সীমা আছে। মডেলের নাম বদলালে এখানে নতুন নাম লিখে দিন।",
            style = MaterialTheme.typography.bodyMedium
        )
        OutlinedButton(onClick = { uri.openUri("https://aistudio.google.com/app/apikey") }) {
            Text("Google AI Studio খুলুন")
        }

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("গোপনীয়তা ও নিরাপত্তা", style = MaterialTheme.typography.titleSmall)
                Text(
                    "• অনলাইন মোডে আপনার প্রশ্ন Google-এর সার্ভারে যায়। ফ্রি টিয়ারে Google প্রশ্ন-উত্তর পণ্য উন্নয়নে ব্যবহার করতে পারে। তাই প্রশ্নে NID, ফোন নম্বর বা ব্যক্তিগত তথ্য লিখবেন না।\n• API Key শুধু এই ফোনে সংরক্ষিত থাকে। কাউকে কী দেবেন না, GitHub-এ আপলোড করবেন না।\n• অফলাইন মোডে কিছুই বাইরে যায় না।\n• AI-এর উত্তর ভুল হতে পারে; ফি, কর ও আইনের বিষয় সরকারি অফিস বা আইনজীবীর কাছে যাচাই করুন।",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        Text("GJ land v2.0", style = MaterialTheme.typography.labelSmall)
    }
}
