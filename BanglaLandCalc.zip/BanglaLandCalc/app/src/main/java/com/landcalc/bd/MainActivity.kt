package com.landcalc.bd

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.landcalc.bd.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = GjColors) { AppRoot() }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val titles = listOf("সহকারী", "গাইড", "টুলস", "রেকর্ড", "সেটিংস")
    val icons = listOf(
        Icons.Default.Face, Icons.Default.Info, Icons.Default.Build,
        Icons.Default.Favorite, Icons.Default.Settings
    )

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(34.dp).clip(CircleShape).background(GjGreen)
                        ) {
                            Image(
                                painter = painterResource(R.drawable.ic_fg),
                                contentDescription = "GJ land লোগো",
                                modifier = Modifier.fillMaxSize().scale(1.8f)
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Text("GJ land")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                titles.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icons[i], contentDescription = t) },
                        label = { Text(t) }
                    )
                }
            }
        }
    ) { pad ->
        val m = Modifier.padding(pad)
        when (tab) {
            0 -> ChatScreen(m)
            1 -> GuideScreen(m)
            2 -> ToolsScreen(m)
            3 -> RecordsScreen(m)
            else -> SettingsScreen(m)
        }
    }
}
