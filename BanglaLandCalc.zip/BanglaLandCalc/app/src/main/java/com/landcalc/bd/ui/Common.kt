package com.landcalc.bd.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.landcalc.bd.LandUnit

@Composable
fun UnitChips(selected: LandUnit, onSelect: (LandUnit) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(LandUnit.values().toList()) { u ->
            FilterChip(selected = u == selected, onClick = { onSelect(u) }, label = { Text(u.bn) })
        }
    }
}

@Composable
fun ResultCard(title: String, lines: List<String>, onShare: (() -> Unit)? = null) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            lines.forEach { Text(it, style = MaterialTheme.typography.bodyLarge) }
            if (onShare != null) {
                TextButton(onClick = onShare) { Text("শেয়ার করুন") }
            }
        }
    }
}

fun shareText(ctx: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(i, "শেয়ার"))
}

const val UNIT_NOTE = "নোট: ১ কাঠা = ১৬ ছটাক = ৭২০ বর্গফুট, ১ শতক = ৪৩৫.৬ বর্গফুট, ১ বিঘা = ২০ কাঠা (ঢাকা মান) ধরা হয়েছে। অঞ্চলভেদে কাঠা-বিঘার মান ভিন্ন হতে পারে; দলিলের মাপ অনুযায়ী নিশ্চিত হোন।"
