package com.landcalc.bd.data

import android.content.Context
import android.content.SharedPreferences

class Prefs(ctx: Context) {
    private val sp: SharedPreferences = ctx.getSharedPreferences("gj_prefs", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) = sp.edit().putString("api_key", v.trim()).apply()

    var model: String
        get() = sp.getString("model", "") ?: ""
        set(v) = sp.edit().putString("model", v.trim()).apply()

    /** 0 = অটো (ইন্টারনেট ও Key থাকলে অনলাইন, না হলে অফলাইন), 1 = শুধু অফলাইন */
    var mode: Int
        get() = sp.getInt("mode", 0)
        set(v) = sp.edit().putInt("mode", v).apply()

    var checked: Set<String>
        get() = sp.getStringSet("checked", emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet("checked", HashSet(v)).apply()
}
