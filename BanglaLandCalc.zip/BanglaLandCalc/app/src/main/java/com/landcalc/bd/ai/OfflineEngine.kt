package com.landcalc.bd.ai

/** অফলাইন তথ্যভাণ্ডার থেকে প্রশ্নের সবচেয়ে মিল থাকা উত্তর খোঁজে (ইন্টারনেট লাগে না)। */
object OfflineEngine {

    data class Hit(val kb: Kb, val score: Double)

    const val CONFIDENT = 3.0

    private val stop = setOf(
        "কি", "কী", "কত", "কেন", "কিভাবে", "কীভাবে", "কোথায়", "কোন", "কোনো", "আমার", "আমি", "আমাকে",
        "করতে", "করব", "করবো", "করি", "হবে", "হয়", "হয়", "লাগে", "লাগবে", "জন্য", "এবং", "ও", "তা", "এই",
        "এটা", "আছে", "নাই", "না", "থেকে", "দিয়ে", "সব", "একটা", "একটি", "যদি", "তাহলে", "বলুন", "বলো",
        "জানতে", "চাই", "দেব", "দিব", "পাব", "পাবো", "ki", "kivabe", "koto", "keno", "ache", "lagbe", "kore"
    )

    private val suffixes = listOf(
        "গুলোর", "গুলো", "গুলি", "দের", "েরা", "কে", "তে", "রা", "ের", "ার", "টির", "টি", "টা", "য়", "র", "ে", "ও", "ই"
    )

    private fun normalize(s: String): String =
        s.lowercase()
            .replace(Regex("[^\\p{L}\\p{N}\\p{M}\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun stem(w: String): String {
        for (suf in suffixes) {
            if (w.length - suf.length >= 2 && w.endsWith(suf)) return w.removeSuffix(suf)
        }
        return w
    }

    private fun tokens(s: String): List<String> =
        normalize(s).split(" ").filter { it.length >= 2 && it !in stop }.map { stem(it) }.distinct()

    private fun matches(q: String, w: String): Boolean {
        if (q == w) return true
        if (q.length >= 3 && w.length >= 3 && (q.startsWith(w) || w.startsWith(q))) return true
        return false
    }

    private class Indexed(val kb: Kb, val keyT: List<String>, val titleT: List<String>, val bodyT: Set<String>)

    private val index: List<Indexed> by lazy {
        KnowledgeBase.entries.map {
            Indexed(it, tokens(it.keys), tokens(it.title), tokens(it.answer).toSet())
        }
    }

    fun search(query: String, limit: Int = 3): List<Hit> {
        val q = tokens(query)
        if (q.isEmpty()) return emptyList()
        val hits = index.map { ix ->
            var score = 0.0
            for (t in q) {
                val w = when {
                    ix.keyT.any { matches(t, it) } -> 3.0
                    ix.titleT.any { matches(t, it) } -> 2.5
                    t in ix.bodyT -> 0.6
                    else -> 0.0
                }
                score += w
            }
            Hit(ix.kb, score)
        }.filter { it.score > 0.0 }
            .sortedByDescending { it.score }
        return hits.take(limit)
    }
}
