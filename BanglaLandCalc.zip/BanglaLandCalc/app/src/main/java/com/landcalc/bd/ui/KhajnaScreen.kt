package com.landcalc.bd.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.landcalc.bd.*

@Composable
fun KhajnaScreen(modifier: Modifier = Modifier) {
    var annual by remember { mutableStateOf("") }
    var years by remember { mutableStateOf("") }
    var extra by remember { mutableStateOf("0") }
    val ctx = LocalContext.current
    val kb = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    val a = parseNum(annual)
    val y = parseNum(years)

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("খাজনা (ভূমি উন্নয়ন কর) বকেয়া হিসাব", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(annual, { annual = it }, label = { Text("বার্ষিক খাজনা (টাকা) — দাখিলা বা পোর্টাল থেকে") },
            keyboardOptions = kb, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(years, { years = it }, label = { Text("কত বছরের বকেয়া") },
            singleLine = true, keyboardOptions = kb, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(extra, { extra = it }, label = { Text("সুদ/জরিমানা (মোটের %) — জানা থাকলে") },
            singleLine = true, keyboardOptions = kb, modifier = Modifier.fillMaxWidth())

        if (a != null && y != null) {
            val base = a * y
            val pct = parseNum(extra) ?: 0.0
            val add = base * pct / 100.0
            val lines = listOf(
                "মূল বকেয়া: ${fmtTaka(base)}",
                "সুদ/জরিমানা: ${fmtTaka(add)}",
                "মোট আনুমানিক: ${fmtTaka(base + add)}"
            )
            ResultCard("আনুমানিক বকেয়া", lines) { shareText(ctx, lines.joinToString("\n")) }
        }
        Text(
            "এটি মোটামুটি হিসাব। প্রকৃত বকেয়া, সুদ ও জরিমানা ldtax.gov.bd বা land.gov.bd পোর্টালে খতিয়ান যোগ করলে নির্ভুল দেখাবে। হটলাইন: ১৬১২২। পরিবারভিত্তিক ২৫ বিঘা পর্যন্ত কৃষিজমির কর মওকুফের বিধান আছে বলে জানা যায়—ভূমি অফিসে নিশ্চিত হোন।",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
